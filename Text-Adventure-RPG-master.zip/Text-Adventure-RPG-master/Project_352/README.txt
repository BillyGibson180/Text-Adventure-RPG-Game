﻿Authors: Hunter Reeves, Billy Gibson
Date: 10/24/2019
File: README.txt
Description: A text based adventure RPG game for 352!

STARTER IDEAS TO IMPLEMENT
- Interactive GUI
- The Story
- Class Selection
- Obtain/Use Loot

ADDITIONAL IDEAS TO IMPLEMENT (IF WE HAVE TIME)
- Gold/Leveling System
- Different Locations/Areas