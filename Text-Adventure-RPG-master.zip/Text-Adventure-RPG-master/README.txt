# Text-Adventure-RPG
Authors: Hunter Reeves, Billy Gibson
Date: 09/26/2019
File: README.txt
Description: A text adventure RPG game for CSCI 352!

STARTER IDEAS TO IMPLEMENT
- Interactive GUI for Gameplay
- The Story (short for the sake of the semester)
- Class Selection (three classes)
- Obtain/Use Loot

ADDITIONAL IDEAS TO IMPLEMENT (IF WE HAVE TIME)
- Gold and Leveling system
- Different Locations/Areas
